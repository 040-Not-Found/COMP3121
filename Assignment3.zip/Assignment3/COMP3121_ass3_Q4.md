# COMP3121 ASSIGNMENT 3

### Question 4

By: Celine Lin z5311209

<img src="/Users/a040/Library/Application Support/typora-user-images/Screen Shot 2021-07-22 at 19.33.20.png" alt="Screen Shot 2021-07-22 at 19.33.20" style="zoom:50%;" />

<img src="/Users/a040/Library/Application Support/typora-user-images/Screen Shot 2021-07-22 at 19.33.56.png" alt="Screen Shot 2021-07-22 at 19.33.56" style="zoom:50%;" />

Firstly, we can consider the following subproblem: What is the maximum enjoyment for the $j^{th}$ activity from day $1$ to day $i$? This will give us three subproblems and the base cases are: 
$$
opt(i,1)=e(i,1),\\
opt(i,2)=e(i,2),\\
opt(i,3)=e(i,3).
$$
The recursion is:
$$
opt(i,1)=\max\{opt(i-1,2),opt(i-1,3)\}+e(i,1),\\
opt(i,2)=\max\{opt(i-1,1),opt(i-1,3)\}+e(i,2),\\
opt(i,3)=\max\{opt(i-1,1),opt(i-1,2)\}+e(i,3).
$$
Now, we can create an array with size $N\times 3$ that stores the $opt(i,j)$, and we can find the maximum enjoyment by 
$$
\max\{opt(N,1),opt(N,2),opt(N,3)\}.
$$
The sequence of activies should be processing while finding $opt(i,j)$, such that
$$
pred[i,j]=\arg\max\{opt(i-1,m),opt(i-1,n)\},
$$
and the sequence will be the $\max\{opt(N,1),opt(N,2),opt(N,3)\}^{th}$ colume of the $pred$ array.

Hence, as we traverse $N$ days finding the maximum enjoyment for three activities, the time complexity will be
$$
3\times O(N)=O(N).
$$
