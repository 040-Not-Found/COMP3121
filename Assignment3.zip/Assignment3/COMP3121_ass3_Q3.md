# COMP3121 ASSIGNMENT 3

### Question 3

By: Celine Lin z5311209

<img src="/Users/a040/Library/Application Support/typora-user-images/Screen Shot 2021-07-22 at 19.32.42.png" alt="Screen Shot 2021-07-22 at 19.32.42" style="zoom:50%;" />

We can solve the subproblem: What is the maximum number of files a frog can catch on accessible lily pad $i$? The base cases of the maximum number of files caught $opt(1)= f_1$, $opt(2)=opt(3)=-1$ and 

​	if $f_4\ge f_5$, $opt(4)=opt(1)+f_4$,

​	else $opt(4)=-1$ and $opt(5)=opt(1)+f_5$.

Now, by traversing the lily pads, $i\ge6$, if the frog can jump on $i^{th}$ lily pad, we can compare the flies with the accessible lily pad besides the $i^{th}$ lily pad, then the frog should to jump to the lily pad with more flies. This can be demonstrate by the recursion:
$$
opt(i) = 
	\begin{cases}
		-1, &\text{if } ((opt(i-3)=opt(i-4)=-1) \\
		&\text{or }(opt(i-3)\ne -1 \text{ and } f_i\ge f_{i+1}))\\
			opt(i-3)+f_i, &\text{if }opt(i-3)\ne -1 \text{ and } f_i\ge f_{i+1}\\
		opt(i-4)+f_i, &\text{if }opt(i-4)\ne -1 \text{ and } f_i\gt f_{i-1}\\
		\max\{opt(i-3),opt(i-4)\}, &\text{else}\\
		
	\end{cases}
$$

We can create an array with size $n$ that stores $opt(i)$. The maximum number of flies that the frog can 

catch will be the maximum of the last four $opt(i)$, such as
$$
\max\{opt(n-3),opt(n-2),opt(n-1),opt(n)\}.
$$
Hence, as we traverse through $n$ lily pads, the time complexity should be
$$
O(n).
$$
