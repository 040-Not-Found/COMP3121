# COMP3121 ASSIGNMENT 3

### Question 2

By: Celine Lin z5311209

<img src="/Users/a040/Library/Application Support/typora-user-images/Screen Shot 2021-07-22 at 19.31.30.png" alt="Screen Shot 2021-07-22 at 19.31.30" style="zoom:50%;" />

We can find the path by to solving the subproblem of finding the minimun number of moves from lower elevation to higher elevation $opt(i,j)$ of the terrain path from $(1,R)$ to $(i,j)$.

Firstly, we have the base cases $opt(1,R)=0$ and $opt(i,j)=\infty$ for all $1\lt i\le C$ and $1\le j\lt R$.

The recursion is:
$$
opt(i,j)=
	\begin{cases}
    opt(i-1,j),&\text{if }j=R \text{ and } elev[i-1,j)\ge elev(i,j)\\
    opt(i-1,j)+1,&\text{if }j=R \text{ and } elev[i-1,j)\lt elev(i,j)\\
    opt(i,j+1),&\text{if }i=1 \text{ and } elev[i,j+1)\ge elev(i,j)\\
    opt(i,j+1)+1,&\text{if }i=1 \text{ and } elev[i,j+1)\lt elev(i,j)\\
		min\{opt(i-1,j),opt(i,j+1)\}, \\
		&\text{if }elev(i-1,j)\ge elev(i,j)\text{ and } elev(i,j+1)\ge elev(i,j)\\
		min\{opt(i-1,j)+1,opt(i,j+1)\}, \\
		&\text{if }elev(i,j+1) \ge elev(i,j) \gt elev(i-1,j)\\
		min\{opt(i-1,j),opt(i,j+1)+1\},\\
    &\text{if }elev(i,j+1) \lt elev(i,j) \le elev(i-1,j)\\
		min\{opt(i-1,j),opt(i,j+1)\}+1,\\
    &\text{if (} elev(i,j) \gt elev(i-1,j)\text{ and }elev(i,j) \gt elev(i,j+1)\text{)}\\
		 
	\end{cases}
$$
We then can solve the subproblem by creating an array with size $R\times C$ that stores the path and $opt(i,j)$ from $(1,R)$ to $(i,j)$, and we can traverse the arrat from the cell $(1,R)$, going left or up, follows by the smaller value to get the path in reverse order.

Hence, for the worst case we will store and compare every square from $(1,R)$ to $(C,1)$, and finding the path takes $O(R+C)$, the time complexity is 
$$
O(R\times C)+O(R+ C)=O(R\times C).
$$
