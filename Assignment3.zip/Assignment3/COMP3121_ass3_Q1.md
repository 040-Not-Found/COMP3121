# COMP3121 ASSIGNMENT 3 

### Question 1

By: Celine Lin z5311209

<img src="/Users/a040/Library/Application Support/typora-user-images/Screen Shot 2021-07-22 at 19.30.36.png" alt="Screen Shot 2021-07-22 at 19.30.36" style="zoom:50%;" />

Suppose we have $n$ symbols, and $n-1$ operations between them. We can split the expression into smaller expressions, for example some range $[i,j]$, where $i\le j\le n$, and solve the subproblems:

1. the number of ways to put parentheses in the range $[i:j]$ that evaluate to $true$, $T(i,j)$, and

2. the number of ways to put parentheses in the range $[i:j]$ that evaluate to $false$, $F(i,j)$.

We have the base cases:
$$
T(i,i)=
  \begin{cases} 
    1, &\quad\text{if } i \text{ is } true,\\
    0, &\quad\text{if } i \text{ is } false,\\
  \end{cases}\\
$$

$$
F(i,i)=
	\begin{cases}
		0, &\quad\text{if } i \text{ is } true,\\
		1, &\quad\text{if } i \text{ is } false.
  \end{cases}
$$

The  recursion is :
$$
T(i,j)=\sum\limits_{k=i}^{j-1}
\begin{cases}
		T(i,k)\times T(k+1,j)\\
		&\text{if operator }k\text{ is AND}\\
		T(i, k) \times T(k + 1, j) + T(i, k) \times F(k + 1, j) + F(i, k) \times T(k + 1, j)\\
		&\text{if operator }k\text{ is OR}\\
		T(i, k) \times F(k + 1, j) + F(i, k) \times T(k + 1, j) + F(i, k) \times F(k + 1, j)\\
		&\text{if operator }k\text{ is NAND}\\
		F(i,k)\times F(k+1,j)\\
		&\text{if operator }k\text{ is XOR}\\
		
  \end{cases}
$$
$$
F(i,j)=\sum\limits_{k=i}^{j-1}
\begin{cases}
		T(i, k) \times F(k + 1, j) + F(i, k) \times T(k + 1, j) + F(i, k) \times F(k + 1, j)\\
		&\text{if operator }k\text{ is AND}\\
		F(i,k)\times F(k+1,j)\\
		&\text{if operator }k\text{ is OR}\\
		T(i,k)\times T(k+1,j)\\
		&\text{if operator }k\text{ is NAND}\\
		T(i, k) \times T(k + 1, j) + T(i, k) \times F(k + 1, j) + F(i, k) \times T(k + 1, j)\\
		&\text{if operator }k\text{ is XOR}\\
		
  \end{cases}
$$

We can create an array with size $n\times n$ that stores $T(i,j)$ and $F(i,j)$ for all $i$ and $j$ that satisfy $j-i=0$, then satisfy $j-i=1$, and so on until $j-i=n-1$. Hence, the number of ways we can evaluate $true$ is $T(1,n)$.

As there are $O(n^2)$ different ranges that the range $[i:j]$ could cover, and each of them can be up to $n-1$ diﬀerent splitting points, the complexity is 
$$
n\times O(n^2)=O(n^3).
$$
