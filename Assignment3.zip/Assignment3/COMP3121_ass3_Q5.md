# COMP3121 ASSIGNMENT 3

### Question 5

By: Celine Lin z5311209

<img src="/Users/a040/Library/Application Support/typora-user-images/Screen Shot 2021-07-22 at 19.34.36.png" alt="Screen Shot 2021-07-22 at 19.34.36" style="zoom:50%;" />

Firstly, let $v_j$ the $j_{th}$ vertex and consider the subproblem: What is the maximum total weight $opt(i,j)$ of a path with length $K$, where $0\le i\le K$ and $0\le j\le V$, that ends at the $v_j$ vertex? The base case is $opt(0,j)=0$ for all $i$.The recursion is:
$$
opt(i,j)=\max\{opt(i-1,k)+weight(k,j)\quad\text{for exist }E_{(k,j)}\}.
$$
We can create an array with size $(K+1) \times V$ that stores $opt(i,j)$ and the predecessor of $v_j$ on the maximum weight path with length $K$ and ends on $j$, for example $opt(i-1,k)+weight(k,j)$. Then the final vertex in the maximum total weight path will be $\arg\max_j opt(K,j)$, and we can traverse the array by the predecessor value from the end of the vertex to get the path of the maximum total weight.

Hence, as we are check every vertex and their corresponding edge, we got the time complexity of $O(\mid V\mid+\mid E\mid)$, and we do this for every length up to $K$, therefore, the total time complexity is
$$
O(K(\mid V\mid+\mid E\mid).
$$
 

