# COMP3121 ASSIGNMENT 4 

### Question 3

By: Celine Lin z5311209

<img src="/Users/a040/Library/Application Support/typora-user-images/Screen Shot 2021-08-01 at 20.08.02.png" alt="Screen Shot 2021-08-01 at 20.08.02" style="zoom:50%;" />

<img src="/Users/a040/Library/Application Support/typora-user-images/Screen Shot 2021-08-01 at 20.08.19.png" alt="Screen Shot 2021-08-01 at 20.08.19" style="zoom:50%;" />

Firstly, we can construct a flow network with the squares be the vertices, and directed edges will be the squares that a child can jump to, i.e. $E(i,i+1), \>E(i,i+2)\dots E(i+k)$, with infinite capacity. The source $s$ of the network will be square $0$ and the sink $t$ will be square $n$. As the squares has limits specifies by the array $A$, we can apply vertex splitting method, described in the lecture slides, for every internal vertices, which gives $v_{i_{in}}$ and $v_{i_{out}}$ by connecting with $A[i]$. This process costs 

$$
\begin{align}
O(|V|+|E|)&=O(2n+(n\times k+n))\\
&=O(n\times k).
\end{align}
$$

Now we then apply the Preflow-Push algorithm, with time complexity $O(V^3)=O((2n)^3)=O(n^3)$​​​​​, to find the maximum flow in such a network. Hence, the maximum flow will be the largest number of children who can successfully complete the game.

Therefore, for the worest case, $k=n-1$, the time complexity is
$$
\begin{align}
O(n(n-1))+O(n^3) &= O(n^2)+O(n^3)\\
&= O(n^3).
\end{align}
$$
