# COMP3121 ASSIGNMENT 4 

### Question 4

By: Celine Lin z5311209

<img src="/Users/a040/Library/Application Support/typora-user-images/Screen Shot 2021-08-01 at 20.08.56.png" alt="Screen Shot 2021-08-01 at 20.08.56" style="zoom:50%;" />

Firstly, we can consider the bipartile graph where every row is a vertex on the left side of the graph and every column is a vertex on the right side. The vertices are the cells that the black rooks can place without being attack. When we are selecting the possible cells, on the $n^2$ chess board, to place the black rooks, we need to comfirm the safty of the cell. As the bishops go diagonally, we need check the diagonals of the cell does not have any white bishops, which we need to check maximal $2 \sqrt{2} n$ cells for every cell. Hence, the cost for the process will be $O(n^2\times 2 \sqrt{2} n)=O(n^3)$. 

Next, we convert this graph into a ﬂow network as follows. Each edges are with capacity of $1$​​. For every rows, we can create a new vertex that have edges to all vertices in the row, and for every columes, a new vertex that have edge to all vertices in a colume. This costs $O(n^2)$ and give us $n$ row vertices and $n$ colume vertices. We then add a super-source $s$ and super-sink $t$ to this graph. We add a directed edge from $s$ to each row vertices anda directed edge from $t$ to each colume vertices. Furthermore, we can apply the Preflow-Push algorithm, $O(V^3)=O(n^3)$​​​, to find the maximum flow which equals the largest number of black rooks we can place that satisfies the conditions.

Hence, the time complexity is 
$$
O(n^3)+O(n^2)+O(n^3)=O(n^3).
$$
