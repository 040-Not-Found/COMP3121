# COMP3121 ASSIGNMENT 4 

### Question 1

By: Celine Lin z5311209

<img src="/Users/a040/Library/Application Support/typora-user-images/Screen Shot 2021-08-01 at 20.06.10.png" alt="Screen Shot 2021-08-01 at 20.06.10" style="zoom:50%;" />

Firstly, we can construct a corresponding flow network with the computers be the vertices and the one-directional links be the directed edges with capacity as the cost of removing the link. This costs $O(|V|+|E|)=O(N+M)$​​​​. The source $s$​​​​​​​ of the network will be computer $1$​​​​​​​ and the sink $t$​​​​​​​ will be computer $N$​​​​​​​. We then apply the Edmons-Karp algorithm, with time complexity $O(|V||E|^2)$​​​​, which is $O(NM^2)$​​​ in this case, to find the maximum flow in such a network. Hence, the links that should disconnect are those that cross the corresponding min cut.

Therefore, the time complexity is
$$
O(N+M)+O(NM^2)=O(NM^2).
$$
