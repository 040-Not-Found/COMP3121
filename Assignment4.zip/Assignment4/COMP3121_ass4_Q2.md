# COMP3121 ASSIGNMENT 4 

### Question 2

By: Celine Lin z5311209

<img src="/Users/a040/Library/Application Support/typora-user-images/Screen Shot 2021-08-01 at 20.07.13.png" alt="Screen Shot 2021-08-01 at 20.07.13" style="zoom:50%;" />

Firstly, we can construct a flow network with the warehouses and shops be the vertices. We add a source $s$ and sink $t$ to the graph, and add directed edges from $s$ to all warehouses and all shops to $t$ with capacity of $1$. This costs $O(2n)=O(n)$.

Now, we can sort the roads is accsending order by the driving time $d_i$, costs $O(m\log{m})$. Then we use binary search to find the minimum time for supplying goods. We can set the fix road $i$, starting from $i = \empheqbiglfloor\frac{m}{2}\empheqbigrfloor$, and add the roads, taking time $\le d_i$, to the network as directed edges with capacity of $1$ for the corresponding warehouse to shops. We then apply the Preflow-Push algorithm, $O(V^3)=O(n^3)$, to find the maximum flow to see if there are $n$ roads matching warehouses with shops. 

- If the maximum flow equals $n$​, then there is a solution in the roads takes  $\le d_i$​​​.

- Else if the maximum flow less than $n$, we repeat the algorithm from the step using binary search, by considering

  - if the minimum supply time exist, replace the edge $d_i$​​ with $\frac{d_i}{2}$​,
  - else, add an edge with $\frac{d_{i+1}}{2}$​​​ to the corresponding warehouse to shop,

  until the maximum flow equals $n$​​ and the maximum flow the network after removed the edge $d_i$ is less than $n$​.

As we are applying the Preflow-Push algorithm when using binary search, the time complexity for this part will be $O(m\log{m})+O(n^3\log{m})$.

Hence, as we find the minimum time for supplying goods $d_i$​​, we can add the edges of the roads, taking time $\le d_i$​​, and apply the Preflow-Push algorithm to construct the final network. Now we can collect the roads in the network that has directed edge from shops to warehouse to a list and have the collection of roads that we can select the minimum time for supplying goods.

Therefore, the time complexity is
$$
O(n)+O(m\log{m})+O(n^3\log{m})+O(n^3)=O(m\log{m})+O(n^3\log{m}).
$$
