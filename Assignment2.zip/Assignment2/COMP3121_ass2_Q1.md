# COMP3121 ASSIGNMENT 2

### Question 1

By: Celine Lin z5311209

<img src="/Users/a040/Desktop/Screen Shot 2021-07-10 at 00.10.05.png" alt="Screen Shot 2021-07-10 at 00.10.05" style="zoom:50%;" />

Firstly, we need to check if $\ell_i < m$, otherwise the $i^{th}$ song must be split across CDs, then this condition fails. Else, we can check the number of minutes left in the song $m_{left}$, where a new CD has $m_{left} = m$. 

- **If** $m_{left} < \ell_i$, this means the $i^{th}$ song is too long for $CD_j$, where $1\le j \le k$, we need to insert the $i^{th}$ song into the next new CD $CD_{j+1}$, and $m_{left} = m$. Then repeat the algorithm from the first step.
  - If we are out of CDs, $CD_{j+1}=CD_{k+1}$, then this process will fail as we cannot include all the songs.
- **Else**, we can insert the $i_{th}$ song into $CD_j$, and $m_{left} = m_{left}-\ell_i$. Then repeat the algorithm from the first step.

**Proof.** When we are inserting songs, every insertion of song is a subproblem taking the greedy choice. After an insertion of a song, we have the same remaining subproblems that is independent from the previous insertion, as we are only looking at the storage remaining in the CD. Therefore, this algorithm is correct as it satisfies the greedy chioce property and optimal substructure. 


Therefore, as we need to insert all the songs, the time complexity for this algorithm is 
$$
O(n).
$$
