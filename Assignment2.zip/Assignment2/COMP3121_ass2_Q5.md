# COMP3121 ASSIGNMENT 2

### Question 5

By: Celine Lin z5311209

<img src="/Users/a040/Library/Application Support/typora-user-images/Screen Shot 2021-07-10 at 00.16.28.png" alt="Screen Shot 2021-07-10 at 00.16.28" style="zoom:50%;" />

Firstly, we can create a list $l$ contains the profit $g_i$, deadline $t_i$, and the index $i$. Then we can use merge sort to make the profit, $g_i$, in descending order. This takes 
$$
O(n)+O(n\log n)=O(n\log n).
$$
Now, by assuming $i >0$, we can create a **zero array** $A$, with size of the latest deadline $t_{max}$, that contains the schedule of the job. Then we can add the first job in the list $l$, the job has the maximum profit, to the schedule, such as $A[t_i] = i$. This indicates the $i^{th}$ job has to be done by $t_i$. We then traversal through the list, 

- **if** the deadline of the $i^{th}$ job has been picked, $A[i] \ne 0$, we need to traversal backwards to find a time for this job. For example: $A[i-j]=i$, where $1\le j \le i - 1$.
  - If the schedule is full before $t_i$, such as $A[i-j]\ne 0$ for all $1\le j \le i - 1$, then we do not add the job to the schedule.
- **Else**, add the job to the schedule, $A[t_i] = i$.

Hence, for the worst case, $t_{max}=n$ , and we need to run through the array everytime when we try to add a job. This can takes 
$$
O(n\times t_{max})=O(n^2).
$$
Therefore, the time complexity for this algorithm will be
$$
O(n\log n)+O(n^2)=O(n^2).
$$
