# COMP3121 ASSIGNMENT 2

### Question 2

By: Celine Lin z5311209

<img src="/Users/a040/Library/Application Support/typora-user-images/Screen Shot 2021-07-10 at 00.14.03.png" alt="Screen Shot 2021-07-10 at 00.14.03" style="zoom:50%;" />

Firstly, we can use merge sort, with time complexity $O(nlogn)$, to put the workers, entry-level jobs in ascending order, and senior jobs in descending order, by their skill level(requirement). Then we can reset the index by their skill level(requirement)'s order.
This process have time complexity of
$$
O(N\log N)+O(P\log P)+O(Q\log Q)=O(N\log N+P\log P+Q\log Q).
$$


Now, starting from $i=1$ and $j=1$, where $1\le i\le N$ and $1\le j \le P$, we can go though entry-level jobs to we find the smallest $p_j$ such that $x_i\le p_j$, and we can assign the $i^{th}$ worker to the $j^{th}$ entry-level job. We then repeat this step for the $i+1^{th}$ worker and keep going from the $j+1^{th}$ entry-level job until $j=P$ or all the workers had assigned to a job. This can be demonstrate by the pseudocode:

``` pseudocode
i = 1, j = 1
for i < N do
	while j < P do
		if worker[i] <= entry_level[j] then
			assign worker[i] to entry_level[j]
			break whileloop
		j = j + 1
  i = i + 1
	if j == P then
		break forloop
```

As this process will traversal the entry-level jobs, for the worst case, hence it have time complexity of 
$$
O(P).
$$
Now, we want to sort the workers, without job, in descending order, by their skill level. Then, starting from $k=1$, where $1\le k \le Q$, we can go though the senior jobs from $q_1$ to find the largest $q_i$ such that $q_k \le x_i$, and assign the $i^{th}$ worker to the $k^{th}$ senior job. We then we repeat this step for the $i+1^{th}$ worker and keep going from the $k+1^{th}$ senior job until $k=Q$ or all the workers had assigned to a job. This is for assign the workers with higher skill level to higher requirement jobs, which can be demonstrate by the pseudocode:

``` pseudocode
i = 1, j = 1
for i < N-M do		// M is the number of workers assigned to entry-level job
	while k < Q do
		if senior[j] <= worker[i] then
			assign worker[i] to senior[j]
			break whileloop
		i = i + 1
  k = k + 1
	if k == Q then
		break forloop
```
As this process sort the works and traversal the senior jobs, for the worst case, hence it have time complexity of 
$$
O(N\log N)+O(Q)=O(N\log N+Q).
$$

Hence, the time complexity for this algorithm is 
$$
O(N\log N+P\log P+Q\log Q) +O(P)+O(N\log N+Q)=O(N\log N+P\log P+Q\log Q).
$$

Therefore, the largest number of workers we can assign 

- if $P+Q > N$, this means every job is assigned by a worker, will be$P+Q$.

- Else, there are $N$, all, workers are assigned for a job.

