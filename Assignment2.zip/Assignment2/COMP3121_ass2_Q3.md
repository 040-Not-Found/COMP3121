# COMP3121 ASSIGNMENT 2

### Question 3

By: Celine Lin z5311209

<img src="/Users/a040/Library/Application Support/typora-user-images/Screen Shot 2021-07-10 at 00.14.43.png" alt="Screen Shot 2021-07-10 at 00.14.43" style="zoom:50%;" />
<img src="/Users/a040/Library/Application Support/typora-user-images/Screen Shot 2021-07-10 at 00.15.01.png" alt="Screen Shot 2021-07-10 at 00.15.01" style="zoom:50%;" />

Firstly, we can get a list $l$, containing the cost $t$, when the hero attacks the monsters $t_i = a_i-g_i$, attacks $a_i$ and gains $g_i$. This have time complexity of
$$
O(N).
$$
Then we separate $l$ into two part, $l_{gain}$ and $l_{lost}$, this can be done by traversal $l$, $O(N)$,

- if $t_i > 0$, this means we can gain strength after killing the monster, we can add sublist $i$ to a list of $l_{gain}$, 
- else, this means we will lost strength after killing the monster, add sublist $i$ to list of $l_{lost}$.

Now, we can sort the list $l_{gain}$ in ascending order of $a_i$, and sort $l_{lost}$ in descending order of $g_i$, using merge sort. This costs 
$$
O(N\log N)+O(N\log N)=O(N\log N).
$$

Therefore, the hero can fight the monsters in the order of $l_{gain}$ then $l_{lost}$. As the hero attacks the monsters in $l_{gain}$ in the given order, his strength will keep increasing, $c = c + t_i$ as $t>0$, and he will get a maximum strength when he kill all the monsters in the $l_{gain}$. Similarly, he should attack the monsters in $l_{lost}$ in the given order.

Hence, the time complexity of this algorithm is
$$
O(N)+O(N\log N)=O(N\log N).
$$
