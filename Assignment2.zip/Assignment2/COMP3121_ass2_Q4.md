# COMP3121 ASSIGNMENT 2

### Question 4

By: Celine Lin z5311209

<img src="/Users/a040/Library/Application Support/typora-user-images/Screen Shot 2021-07-10 at 00.15.51.png" alt="Screen Shot 2021-07-10 at 00.15.51" style="zoom:50%;" />

For index $0 \le i \le n-2$, we can remain $i$ blocks on the $i^{th}$ stack and move the rest of the blocks to the $(i+1)^{th}$ stack. For every movement, we can update a array $A$, with size $n-1$, such that $A[i]=i$. 

- If $A[i] < i$, then it is impossible to make the size of stacks strictly increasing, as 

$$
\begin{align*}
h_{i-1}&=A[i-1]\\
&=i-1\\
A[i] &< i\\
&=h_i\\
\therefore h_i &\le h_{i-1}.
\end{align*}
$$

After moveing the blocks $n-1$ times, this will gives the array $A$ be like 
$$
A=[0,1,2,...,n-2,h_n].
$$
- If $h_n>n-2$, then the size of stacks strictly increasing. 

Hence, as we traversal $n-1$ stacks and check $A[n-1]$, the time complexity for the algorithm will be 
$$
O(n-1)+O(1)=O(n).
$$
