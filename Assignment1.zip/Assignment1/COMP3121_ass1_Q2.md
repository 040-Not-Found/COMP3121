# COMP3121 ASSIGNMENT 1 

### Question 2

By: Celine Lin z5311209

<img src="/Users/a040/Library/Application Support/typora-user-images/Screen Shot 2021-06-13 at 21.11.37.png" alt="Screen Shot 2021-06-13 at 21.11.37" style="zoom:50%;" />

Firstly, we can search for the minimum $y$, time complexity of $O(n)$, then we can get the minimum range of $E$. This is because  $y_{min}$ will corresonds to  $c_{min}$, which is 1. Hence, $E$ will be in between 0 and the  $y_{min}$ - 1. i.e.

$$
0 < E < y_{min} - 1.
$$

Now, we can use **half-interval search**, time complexity of$ O(\log(n))$, to find the value of $E$. This is by finding the middle $E_{possible}$, and find $S_{E_{possible}} =\sum_{i=1}^{n}\frac{x_i}{y_i - E_{possible}}$, this takes $O(n)$. 

​	If $S_{E_{possible}} > S$, this means $E_{correct}<E_{possible}$, so that $E_{correct}$ is in the left half of the previous possible range, which is the new possible range. Hence, we need to repeat the process using the new possible range. e.g. for the first trial

$$
0 < E < E_{middle}.
$$

​	Similarly, if  $S_{E_{possible}} < S$, then $E_{correct}<E_{possible}$, the new possible range will be the right half of the previous possible range, e.g. for the first trial

$$
E_{middle} < E < y_{min} - 1.
$$

Keep finding the $E_{possible}$ until $S_{E_{possible}}=S$, then $E_{possible}=E$.

Hence, the time complexity for this algorithm will be

$$
O(n) + O(n\log(y_{min}))= O(n\log \min\{{y_i:1\le i\le n}\}).
$$

