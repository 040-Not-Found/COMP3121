# COMP3121 ASSIGNMENT 1 

### Question 3

By: Celine Lin z5311209

<img src="/Users/a040/Library/Application Support/typora-user-images/Screen Shot 2021-06-13 at 19.47.15.png" alt="Screen Shot 2021-06-13 at 19.47.15" style="zoom:50%;" />

We can use **Merge Sort**, time complexity of $O(n\log(n))$, to make the $A$ in ascending order. For each pair of the integers, we can find the index of both smallest element greater than or equal to $L_i$ and smallest element greater than $U_i$, i.e. 

```txt
// element1 and element2 are index
element1 = (smallest_element >= L_i), 
element2 = (smallest_element > U_i),
```

using binary search, time complexity of $O(\log(n))$.

Therefore, the number of elements between $L_i$ and $U_i$ is difference between the index of the two elements, i.e.

$$
num_{elements} = element{2}-element{1}.
$$

Hence, the time complexity for this algorithm is

$$
O(nlogn)+O(logn)= O(nlogn)
$$