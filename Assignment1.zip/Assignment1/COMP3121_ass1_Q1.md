# COMP3121 ASSIGNMENT 1 

### Question 1

By: Celine Lin z5311209

<img src="/Users/a040/Library/Application Support/typora-user-images/Screen Shot 2021-06-13 at 13.57.26.png" alt="Screen Shot 2021-06-13 at 13.57.26" style="zoom:50%;" />


##### (a)

Firstly, we can generate a list **L** of lists containing the collocation($a^2+b$) of the items in the array. The list **L** will be like
$$
[[a^2+b, a, b], [a^2+c, a, c]...[b^2+a, b, a]...]
$$
where $a,b,c$ are the distinct positive integers in the array **A**, and the time complexity is $O(n^2)$, and the list **L** will contains $n^2$  sublists.

Now, we use **Merge Sort** to list **L** to make the first element of the sublist in ascending order, so **L** will be like

$$
[[z, m, s], [z, m, b], [z, k, p], [y, h, i]...]
$$

As the time complexity in the worst case for **Merge Sort** is $O(nlogn)$, and there are $n^2$ elements in the list **L** , the time complexity at this stage is

$$
\begin{align*}
O(n^2log(n^2))&=O(2n^2logn)\\
&= O(n^2logn)
\end{align*}
$$

Finally, we can check if there exist four distinct integers by comparing the sublists with the same first element. If there exist four or more sublists containing the same first element, there must be four distinct integer such that $m^2+s = k+p^2$:

$$
[[z, m, s], [z, a, m], [z, s, b], [z, p, k]...]
$$

Therefore, there are maximum three sublists for every same first element, expect the ones that exist four or more distinct integers. So the time complexity in the worst case for comparing the sublist will be $O(n^2)$.

Hence, the time complexity for this algorithm is

$$
O(n^2logn)+O(n^2) = O(n^2logn)
$$


##### (b)

We can use store the sublists of $L$, from part (a), into a hash map of $n^2$ slots, and the first element, $m^2+s$, of the sublist will be the key of each slot. The expected time for hash map insertion is $O(n)$, and as we have $n^2$ elements, the time complexity will be $O(n^2)$.

While inserting, check if slot is empty. 

​	If **not**, check if the $m = k$ and $s=p$.

​		If **not equal**, there is exist four distinct integers such that $m^2+s=k+p^2$.

​		**else**, insert the sublist as normal.

​	**else**, insert the sublist as normal.

If the slot contains three sublist/elements already, the fourth sublist must be $[k+p^2,p,k]$, which there is exist four distinct integers such that $m^2+s=k+p^2$.

Hence, the complexity for this algorithm is
$$
O(n^2).
$$
