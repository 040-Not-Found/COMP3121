# COMP3121 ASSIGNMENT 1

### Question 4

By: Celine Lin z5311209

<img src="/Users/a040/Library/Application Support/typora-user-images/Screen Shot 2021-06-13 at 19.23.51.png" alt="Screen Shot 2021-06-13 at 19.23.51" style="zoom:50%;" />

We can use the **half-interval search **, time complexity of $O(\log(n))$, to find the missing term. The time complexity of this search algorithm is $O(\log(n))$, however, as we have $2^n-1$ elements, the time complexity will be

$$
\begin{align*}
	O(log(2^n-1))
&= O(nlog(2))\\
&= O(n).
\end{align*}
$$

Firstly, we can find the middle element $A[m]$ and check if it is even. 

​	If **even**, this means the sequence is consistent up the middle term, so the missing term will be in the right half of the sequence, then check if the difference between middle element and its next element is greater than 1, i.e.

$$
A[m + 1] - A[m] > 1
$$

​		If **yes**, then the missing element is  $A[m] + 1$.

​		**else**, then we need to repeat the half-interval process by taking the right half of the array.

​	**else**, is odd, check if the difference between middle element and its previous element is greater than 1, i.e.

$$
A[m] – A[m – 1] > 1
$$

​		If **yes**, then $A[m] – 1$ is the missing element.

​		**else**, then we need to repeat the half-interval process by taking the left half of the array.

Therefore, the time complexity of this algorithm is

$$
O(n)
$$