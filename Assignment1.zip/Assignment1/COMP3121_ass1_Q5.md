# COMP3121 ASSIGNMENT 1 

### Question 5

By: Celine Lin z5311209

<img src="/Users/a040/Library/Application Support/typora-user-images/image-20210613205420075.png" alt="image-20210613205420075" style="zoom:50%;" />

<img src="/Users/a040/Library/Application Support/typora-user-images/image-20210613205448381.png" alt="image-20210613205448381" style="zoom:50%;" />

##### (a) 

Clearly, as both $f(n)$ and $g(n)$ are differentiable and

$$
\begin{align*}
\lim_{n \to \infty} f(n)=\lim_{n \to \infty} g(n)=\infty
\end{align*},
$$

then we can applying the l'Hôspital's rule:

$$
\lim_{n \to \infty} \frac{f'(n)}{g'(n)}=\lim_{n \to \infty} \frac{10}{\ln (2)\sqrt[10]{n}}=0.
$$
Hence, as $\lim_{n \to \infty} \frac{f'(n)}{g'(n)} = 0$, which means $f(n) \le g(n)$ when $n \to \infty$, 
$$
f(n)=O(g(n)).
$$

##### (b)

As 
$$
\begin{align*}
g(n) &= 2^{n\log(n^2)}\\
&= n\log(n^2)\\
&= \log(n^{2n})\\
&= n^{2n}\\
&\ge n^n\\
&= f(n)
\end{align*}
$$

Hence, as $ g(n) \ge f(n) $ for $n \in \N$,
$$
f(n)=O(g(n)).
$$


##### (c)

As $\sin(\pi n)=0$ for $n \in \N $, so

$$
\begin{align*}
f(n)&=n^{1+0}\\
&=n \\
&=g(n).
\end{align*}
$$

Hence, $f(n) = \Theta (g(n))$. 

(However, if $n \in \R$, $f(n)$ is boundedly divergent, therefore, neither $f(n)=O(g(n))$ nor $g(n)=O(f(n))$.)
